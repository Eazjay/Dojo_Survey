from django.apps import AppConfig


class DojoAppConfig(AppConfig):
    name = 'Dojo_app'
